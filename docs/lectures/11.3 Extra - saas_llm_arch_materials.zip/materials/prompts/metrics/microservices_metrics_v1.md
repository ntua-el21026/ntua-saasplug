You are tasked with calculating architecture metrics from a generated PlantUML architecture.

For two-step runs, use the PlantUML provided below.
For one-step runs, use the architecture generated earlier in the same response.

Requirements:
{INPUT_REQUIREMENTS}

Architecture style:
{ARCHITECTURE}

Generated PlantUML:
{GENERATED_PLANTUML}

Calculate the following characteristics of the architecture.

General characteristics:

SI: Counts services that do not carry persistent state across requests and divides by the total number of services.
SI = (# of stateless services) / |Total number of services|

DOC (Data Ownership Count): Counts services that manage a dedicated data store and divides by the total number of services.
DOC = (# of services linked to a dedicated data store) / |Total number of services|

SST (Service Support for Transactions): Counts services that have at least one operation classified as "Data consistency operation" and divides by the total number of services.
SST = (# of transaction-aware services) / |Total number of services|

Characteristics per service:

SIC (Service Interface Count): Number of interfaces of service S.
AIS(in): Number of distinct consumers of service S.
ADS(out): Number of distinct services called by service S.

Characteristics per use case:

SC: Set of services involved for the completion of one use case.
SC = {{(Set of microservices involved per use case) MS SET}}

Use only the requirements and PlantUML above. If a value must be inferred, infer it conservatively from explicit services, operations, associations, and operation comments.

Respond exactly as JSON with this shape and no extra text:
{{
  "SI": "",
  "DOC": "",
  "SST": "",
  "services": [
    {{
      "service_name": "",
      "SIC": "",
      "AIS(in)": "",
      "ADS(out)": ""
    }}
  ],
  "use_cases": [
    {{
      "use_case_name": "",
      "SC": ""
    }}
  ]
}}
