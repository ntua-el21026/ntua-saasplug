Task Description: You are tasked with processing a software description and its requirements to generate a class diagram using PlantUML. The class diagram should respect the requested software architecture, define all necessary classes, and accurately represent associations between them.

Functional requirements:
{FR}

Non-functional requirements:
{NFR}

The demanded Architecture is: {ARCHITECTURE}

Additional retrieval context:
{RAG_CONTEXT}

Generate only the PlantUML class diagram. Do not calculate metrics.

Use proper microservices design: bounded contexts, loose coupling, independent deployability, high cohesion, dedicated data ownership, eventual consistency, choreography/orchestration, API gateway and/or messaging flow control, and satisfaction of non-functional requirements.

The PlantUML must define packages, classes, attributes, methods, and all associations/service dependencies. Classify each operation by commenting next to it with one of:
- Functional requirement-business logic operation
- Data management operation
- Data consistency operation
- Flow control operation

Class diagram constraints:
- The output must start with @startuml and end with @enduml.
- Use only class-diagram constructs: package, class, interface, enum, abstract class, associations, dependencies, aggregations, compositions, and inheritance.
- Every package must have a quoted or valid name, for example: package "Chart Service" { ... }.
- Do not output anonymous packages such as "package {" or a line containing only "package".
- Include explicit relationships between classes/services using PlantUML relationship arrows such as -->, ..>, o--, *--, <|--.
- Include at least one relationship for every service class unless it is truly isolated.
- Do not generate sequence diagram syntax such as participant, actor, -> messages, activate, deactivate, or lifeline calls.
