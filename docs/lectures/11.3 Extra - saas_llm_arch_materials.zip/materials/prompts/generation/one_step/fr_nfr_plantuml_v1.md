Task Description: You are tasked with processing a software description and its requirements to generate a class diagram using PlantUML. The class diagram should respect the requested software architecture, define all necessary classes, and accurately represent associations between them.

The requirements for the software we want you to design are described below:

Functional requirements:
{FR}

Non-functional requirements:
{NFR}

The demanded Architecture is: {ARCHITECTURE}

Additional retrieval context:
{RAG_CONTEXT}

Important guidelines for designing proper microservices architecture:

1. Functional Alignment & Responsibility Distribution
Focus: Ensure that each microservice maps to a bounded context and implements a focused set of functionalities. The union of the functionalities of each microservice should be the entire set of functional requirements.

2. Coupling & Deployment Independence
Focus: Ensure that microservices are loosely coupled and independently deployable.

3. Cohesion
Focus: Ensure high cohesion, meaning that more than one microservice needs to be involved in the completion of each use case.

4. Data Management
Focus: Ensure that each service is responsible for managing specific data elements without using shared databases.

5. Data Consistency
Focus: Ensure that operations to achieve eventual consistency of data states among different microservices are included.

6. Communication & Flow Control
Focus: Ensure that service coordination is done using choreography or orchestration mechanisms. API gateways and/or messaging services should be used to implement flow control.

7. Non-Functional Requirements
Focus: Ensure that the design satisfies all problem-specific non-functional requirements.

First, generate a class diagram using PlantUML that defines all necessary classes and associations based on the described architecture, requirements, and functionality. Ensure that the diagram reflects separation of concerns, defines attributes and methods, includes associations and service dependencies, and creates appropriate packages.

PlantUML class diagram requirements:
- The output must start with @startuml and end with @enduml.
- Use only class-diagram constructs: package, class, interface, enum, abstract class, associations, dependencies, aggregations, compositions, and inheritance.
- Every package must have a quoted or valid name, for example: package "Chart Service" { ... }.
- Do not output anonymous packages such as "package {" or a line containing only "package".
- Include explicit relationships between classes/services using PlantUML relationship arrows such as -->, ..>, o--, *--, <|--.
- Include at least one relationship for every service class unless it is truly isolated.
- Do not generate sequence diagram syntax such as participant, actor, -> messages, activate, deactivate, or lifeline calls.

Classify each operation by commenting next to the operation in PlantUML with one of these groups:
- Functional requirement-business logic operation
- Data management operation
- Data consistency operation
- Flow control operation

Then calculate the architecture metrics.

Respond exactly in this order:

ARCHITECTURE_OUTPUT_START
<PlantUML here, including @startuml and @enduml>
ARCHITECTURE_OUTPUT_END

METRICS_JSON_START
<metrics JSON here>
METRICS_JSON_END

Metrics instructions:

{METRICS_PROMPT}
