Task Description: You are tasked with processing a software requirements specification to generate Architecture-as-Code as a C++ header file. The generated C++ header should respect the requested software architecture, define all necessary classes, and accurately represent associations between them.

The software requirements specification is described below:

{SRS}

The demanded Architecture is: {ARCHITECTURE}

Additional retrieval context:
{RAG_CONTEXT}

First, generate only valid C++ header content that expresses the architecture as code. Use namespaces for architecture layers, bounded contexts, or services. Define classes, fields, methods, inheritance, and service dependencies in a way that can be parsed by CppHeaderParser. Do not include method bodies. Do not include markdown fences.

Use proper microservices design: bounded contexts, loose coupling, independent deployability, high cohesion, dedicated data ownership, eventual consistency, choreography/orchestration, API gateway and/or messaging flow control, and satisfaction of non-functional requirements.
Critical: Encode all service-to-service dependencies explicitly:
- Add member variables (pointers or references) for each service dependency
- Include constructor parameters that accept dependencies
- Add method signatures that show which other services are called
This ensures the diagram will capture all architectural relationships.
Then calculate the architecture metrics.

Respond exactly in this order:

ARCHITECTURE_OUTPUT_START
<C++ header here>
ARCHITECTURE_OUTPUT_END

METRICS_JSON_START
<metrics JSON here>
METRICS_JSON_END

Metrics instructions:

{METRICS_PROMPT}
